

// Function to check if an event with the same name exists on the same day
export const isEventNameUniqueOnDate = (events, eventName, date) => {
    return events.some((event) => event.name === eventName && event.date === date);
};

// Function to check if two events have overlapping start and end times on the same day
export const doEventsOverlap = (events, startTime, endTime, date) => {
    return events.some(
        (event) =>
            event.date === date &&
            ((startTime >= event.start_time && startTime < event.end_time) ||
                (endTime > event.start_time && endTime <= event.end_time))
    );
};

